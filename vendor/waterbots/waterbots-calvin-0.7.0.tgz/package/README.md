# @waterbots/calvin

Calvin is the module that quantifies: the carbon calculator. It arrived as a seed, a one-time copy carried over by the maintainer. `SEEDS.md` at the root of this repo records what arrived, when, and what was checked.

What is in `src/`:

- `calculators/gs4gg-carbon/`: the engine, with its tests on made-up cases. The engine does every sum.
- `calculators/data/`: the engine's data files, each citing its sources, and a test for each.
- `modules/calvin/`: the screens and their state, the notes and tools the agent reads, and `engine.ts`, the one door to the engine. The screens compute nothing.
- `modules/core/`: six small files that pass the seed's shared imports on to `@waterbots/core`. They are not part of the seed.
- `agents/`: Calvin's prompt, tool list and notes. The rules every agent follows come from `@waterbots/core` (`agent-rules.md`).
- `sources/public-index.yaml`: the sources the data cites: titles, publishers, links and rights words only.
- `expected-outputs.json` and `prove-expected-outputs.test.ts`: the engine's results on made-up cases, and the test that re-runs them.
- `engine.ts`: the engine-only entry (see below). It is not part of the seed.
- `screen.ts`: the screen entry (see below). It is not part of the seed.

Two data files are cut down on purpose. The table of fallback factors holds six rows only, and the baseline mix is a labelled stub with no country data. The reason is in `SEEDS.md`.

## The engine on its own

`@waterbots/calvin/engine` is the calculator's math and its data, with no screens. It needs neither React nor `@waterbots/core`. A site or tool can use it alone:

```js
import { computeScenario, GS4GG_CALCULATOR_VERSION } from "@waterbots/calvin/engine";
```

The build bundles it into one plain file, `dist/engine.js`, that runs in Node or a browser. React is an optional peer: install it only to use the screens.

Two checks run on every `npm test`. `test/engine-entry.test.mjs` checks that the entry imports nothing but the engine and gives the same answers as `expected-outputs.json`. `scripts/check-engine-entry.mjs`, at the repo root, builds the entry, installs it alone in a folder with no React, and checks the same 48 answers there.

## The screens

`@waterbots/calvin/screen` is what a site needs to mount Calvin's screens: the state hook, the controls panel, the work surface, the report and the version tabs, with their types.

```jsx
import { useCalculatorState, CalculatorLens, CalculatorWork } from "@waterbots/calvin/screen";
import "@waterbots/calvin/styles.css"; // every site: the report's print rules
import "@waterbots/core/base.css"; // only a site without a design system of its own

function Seat({ project }) {
  const calc = useCalculatorState(project, { exAnteOnly: true });
  return (
    <>
      <CalculatorLens calc={calc} />
      <CalculatorWork calc={calc} project={project} appVersion="0.4.0" tab="calculator" />
    </>
  );
}
```

There are two views:
- **The ex-ante view**, for a project that has not run yet. With `exAnteSliders` on, the values a project can only anticipate are set on sliders.
- **The ex-post view**, for a project that has run, with its measured values in typed boxes.

A site that shows both (the paid site) offers its own switch between them. A site that shows only the ex-ante view (the open site's screening) passes `exAnteOnly: true`. Then every run is ex-ante, a saved ex-post analysis opens as ex-ante, and the sliders are on.

### New projects and transitioning projects

Each project also says whether it was already credited under the V1.0 methodology. The site passes it on the project as `creditedUnderV1`, from its own intake:

- **`creditedUnderV1: true`**: a transitioning project. The screens show both versions and the transition: how the credits move from V1.0 to V2.0. They ask for the project's filed V1.0 fNRB (the share of firewood counted as unsustainably harvested) before they show the comparison.
- **`false`, or left out**: a new project, on paper or newly built. The screens show V2.0 only. There is no V1.0 figure, no transition, and no ask for a V1.0 filing the project does not have.

Left out means V2.0 only because the V2.0 figure is true for every project. Only the comparison needs a V1.0 filing.

```jsx
const project = { name: "Invented project", standards: [], technology: "CWS", country: "LSO", creditedUnderV1: true };
```

The build bundles the entry into one file, `dist/screen.js`. React and `@waterbots/core` stay outside it, so a site has one copy of each. `scripts/check-screen-entry.mjs`, at the repo root, packs both packages, installs them alone with React, and renders the ex-ante view, the ex-post view and its report, a new project's V2.0-only view and report, and a transitioning project's view and report from the packed files.

## The agent

`@waterbots/calvin/agent` is what a host needs to run Calvin as an agent, at any door, with no React:

- his two tools, `computeScenarioTool` and `transitionWaterfallTool` (`GS4GG_CARBON_TOOLS`);
- the shared project record (J3): `calvinProjectFromRecord` reads it, `calvinNeeds` lists the facts it still lacks,
  `addCalvinFacts` adds what the person gave him, and `addCalvinResults` writes his inputs and his V2.0 figure;
- his two choices in the Agent Commons, `CALVIN_COMMONS_CHOICES`. Each sets `creditedUnderV1`. Their words wait for
  the maintainer's ruling, so none are shipped yet;
- `calculatorPageContext`, what he can see of his screen.

A site tells the screens where Calvin is working with `place` (`"free-site"`, `"paid-site"`, `"agent-commons"` or
`"mcp"`, from `@waterbots/core/places`). Left out, it is a site with a project record, as before.

The build bundles the entry into one file, `dist/agent.js`. `@waterbots/core` stays outside it.
`scripts/check-screen-entry.mjs` loads it from the packed files and runs his tool there.

## Changes in 0.7.0 (not released yet)

Calvin accepts any `@waterbots/core` in the 0.3 series, so he can be released on his own.

- **His chat (J5).** `@waterbots/calvin/agent` gives what a site needs to run it:
  - `CALVIN_OPENED`, the turn that opens it, so he speaks first; `CALVIN_CHAT`, the model and how long a reply may be.
  - `calvinAsks`: what is still missing, in order, project facts only. `calvinKept`: the values at their default or their
    assumed start. Both are also on the seat, as `calc.asks` and `calc.kept`.
  - `CALVIN_ANSWER_SCHEMA` and `readCalvinAnswer`: the shape of his answer, and its reader. `calc.fill(answer)` fills the
    seat; a number outside its range is refused with its message. Project facts go to the record (`addCalvinFacts`).
  - `calvinChatContext`: the block for one turn. It says what to do when his part is done at each place.
- **His files ship:** `@waterbots/calvin/prompt.md`, `knowledge.md` and `config.yaml`.
- **Value ranges (ruled 2026-11-23).** A number outside a value's range is refused where it is typed, with a message that
  names the value and the range. It is never used: the value in force goes back to what it was. A number from the
  record or an older save that is outside its range is shown with its message, and no figures show until it is put
  right. His tools refuse the same numbers in the same words. The 5.5 litres stays a method cap: a higher figure is
  kept, and the credit is capped.
- **Two top ends with no source are gone.** Litres a day has no top. Stove efficiency runs up to 100%.
- **Not covered yet.** His tools now ask for the `technology`, and the method follows it. They refuse community level
  and institutional treatment. A project whose label is not covered yet gets a sentence that says so (`notCoveredYet`
  on the project; `calvinProjectFromRecord` sets it).
- **A box in an asking panel waits** for Enter, for the person to leave it, or for a short pause. Before, the panel closed
  on the first digit.
- No sum changed.

**What a site should change.** A site that calls his tools itself passes `technology`. A site with its own chat for him
puts together core's agent rules, his three files and `calvinChatContext`, makes the call with its own key, and hands the
answer to `readCalvinAnswer`, the record and `calc.fill`. Messages for refused numbers go in `refused` on the next turn.

## Changes in 0.6.0

From 0.6.0 Calvin and Violet each have their own release. Calvin needs `@waterbots/core` 0.2.0.

- **The shared project record (J3).** Calvin reads the record and adds what he asked for and his results. People
  served keep the way they were entered.
- **His place (J2).** The `place` option, and the agent entry above. In the Agent Commons and at MCP he is told there
  is no record.
- **A count below zero on the record (W1).** Calvin is told it is wrong, not missing. The screen's words are unchanged.
- **One calculator screen (J5).** Calvin's screen and Violet's now match.
  - **Notes on values.** On the Paid site (`place: "paid-site"`) every value row and equation row takes the person's
    note, and the report lists them under "Notes on values". A read-only seat sees them and cannot write. The site
    passes `notes` (the record's `agents.calvin.notes`) and `onNotesChange`, and saves the notes with the record.
  - **Calvin's own notes.** The report on the Paid site, the Free site and in the Agent Commons carries his notes on
    the values still blank or assumed. They follow the tags the screen shows. The Paid site's report shows both kinds
    of note, each under its own label. The Free site and the Agent Commons have no note box.
  - **His tools say which values are blank or assumed.** Each tool's output gains `blankOrAssumed`: a key, a name and
    "blank" or "assumed" for each, as facts. At MCP there is no export, so the visitor's own AI says them.
  - **His colour** on the header card, through the shared `--agent` name: Tide for now.
- No sum changed.

**What a site should change (J5).** Install `@waterbots/core` 0.2.0 with it. Pass `place`. The Paid site passes `notes`
and `onNotesChange`, and keeps the notes on the record. A site with its own export puts `calc.noteLines` in it, the
person's lines (`by: "person"`) and Calvin's (`by: "agent"`) each under its own label (`NOTE_WORDS.byPerson` and
`agentNotesLabel("Calvin")`, from `@waterbots/core/notes`).

## Changes in 0.5.1

With Violet 0.5.1, for both sites. No sum changed, and every test case gives the same answer.

- **A missing value is a blank box, with no label.** In the ex-post ask, a monitoring value not yet entered has a
  blank box, its highlight and red dot, and nothing written under it. In the report's tables and on the equations, a
  value that is not there shows blank, in its value and its source cells, where it used to show "—" or
  "Not entered". A blank never counts as zero: with a monitoring value missing, no figures show.
- Where a sentence says what the sum did without a value, it stays, without the "Not entered" label. For example:
  "Eq.6 could not run; people-basis aggregate used".
- **The agent rules come from core.** Calvin reads the foundational agent rules, rules 1 to 21, from
  `@waterbots/core/agent-rules.md`. The copy in `agents/_base-rules.md` is gone. Calvin's prompt and notes now hold only
  what is different for him, in a warmer voice.
- **The tool's words.** The descriptions of his tool's inputs, and the messages the tool hands back to the agent,
  say what each fact is. They no longer list what the agent must not do; the agent rules cover that.
- **Core 0.1.2.** Calvin needs `@waterbots/core` 0.1.2, which ships the agent rules file.
- Old pointers in code comments are cleaned up. No code changed for them.

**What a site should change.** A site that loads Calvin's agent loads the rules from
`@waterbots/core/agent-rules.md`, where it loaded `agents/_base-rules.md` before. No exported name changed.

## Changes in 0.5.0

Released with Violet 0.5.0, for both sites. No sum changed, and every test case gives the same answer.

**A pinned header.** The main credit figures stay at the top while the reader scrolls: the PAA v2.0 tile in tCO₂e a
year, and for a project credited under V1.0 the Legacy V1.0 tile and the transition delta too. The smaller figures
sit right under them. Everything below can collapse: the sliders and the calculation each have a title that opens
and closes them. Both start open.

- `unpinFigureBlock` still works. Left out, the smaller figures stay pinned with the tiles. Set to `true`, the tiles
  stay pinned and the smaller figures scroll away with the page.
- On a phone (narrower than 640 pixels), only the tiles stay pinned, so the header never fills the screen.
- The pin lives in Calvin's stylesheet, `@waterbots/calvin/styles.css`, which every site already imports.

**What a site should change.**

- Keep importing `@waterbots/calvin/styles.css`. The pinned header, the phone layout and the parts that collapse are
  in it.
- The header pins to the top of the area that scrolls. A site with a fixed bar of its own at the top sets
  `--calvin-pin-top` to that bar's height, for example `--calvin-pin-top: 56px`. A site whose page colour is not
  `--card` can set `--calvin-pin-bg`.
- Nothing between the work surface and the area that scrolls may clip its overflow (`overflow: hidden` or `auto`).
  If something does, the header cannot pin.
- A site that set `unpinFigureBlock: true` can keep it: the tiles stay pinned either way. A site that wants the
  smaller figures pinned too leaves it out.
- The controls panel now holds only what the site passes in `header`, and Calvin's buttons. A site that puts an
  introduction of its own in `header` and no longer wants it there takes it out.
- `referenceCaseCount` is no longer shown. It is still accepted, so a site that passes it keeps working.
- `VersionTabs` takes `showNote`. Left out, it shows the sentence under its tiles, as before.

**What a visitor sees.**

- The controls panel holds only the site's own top and Calvin's buttons.
- The work surface ends with the calculation.
- The report's paragraph "How these figures were produced" is one sentence shorter.
- On a phone, nothing is squeezed: when a value's label would get too narrow, its tags and box move to a line of
  their own. The line about the pencil wraps as plain text.

## Changes in 0.4.1

Monitoring values are labelled by the analysis basis. No sum changed, and every test case gives the same answer. Only what the screens say, and when they show figures, changed.

**Which values the rule covers.** The maintainer is asked to confirm this list.

- The operating days: DO for a community system, DP (days the device is in the home) for a household device.
- The share of water tests that pass, M_q.
- The usage rate, U_p. Household devices only.
- The share still boiling the safe water, X_cleanboil.

**Not covered:** the metered volume, Q_m. It is a cap, and it stays optional. Left blank, no cap applies, as before. The baseline values (C_b and the stove and fuel mix) are not monitoring data, so they keep their own labels.

**Ex-ante (before the project runs).** Each value starts at its starting value and is labelled "Assumed", on the screen and in the report. The operating days start at a full year on the typed boxes, and at 347 days on the sliders. A value the person changes is their planned figure. It is still labelled assumed, and the label says where the figure will come from after the project runs.

**Ex-post (after it runs).** Each value comes from the operation log or monitoring, and is labelled so: for example, "From the operation log or sensor (V2.0 SDWS 32)". Until it is entered, its box is blank. There is no starting value and no fallback. The box has a light highlight and a small red dot. No figures are shown until every value is entered.

**Moving from ex-ante to ex-post asks again.** A figure entered ex-ante is a planned figure, not a monitored one. So a change of the run to ex-post clears the "entered" marks, and the screen asks for each value. Moving back to ex-ante keeps them.

**The "entered" flags are saved.** The analysis now saves four flags: `operationalDaysEntered`, `mQualityEntered`, `usageRateEntered` and `xCleanboilEntered`. A save never turns an entered value back into an assumed one, or the reverse.

- A saved flag is read as it stands.
- A save made before 0.4.1 has no flags. A value other than a starting value reads as entered. A starting value reads as assumed, so an older ex-post analysis may ask again for a value it holds.
- `slidersEntered` is still read from older saves, and is no longer written. The four flags replace it.

**For a site.** `CalculatorState` has a new field, `missingMonitoring`: the values an ex-post run still needs. It is empty on an ex-ante run. The agent's page context tells Calvin there are no figures, and not to offer a stand-in.

## Changes in 0.4.0

From the maintainer's walk of the open site (2026-11-16). No sum changed, and every test case gives the same answer.

**Two new settings on `useCalculatorState`.** Both are off by default, so a site that passes neither sees no change.

- `unpinFigureBlock: true` lets the block of headline figures above the equations scroll away with the page. By default it stays pinned at the top.
- `hideExportButton: true` hides Calvin's two export buttons: "Export report (PDF)" in the controls panel and "Export (PDF)" on the report tab. The report itself still shows.

**A new project fact, `pumpPower`.** The site passes what powers the pump: `"hand"`, `"gravity"`, `"solar"`, `"diesel"` or `"grid"`. For diesel or grid power, the screens ask for the pump's yearly emissions (tCO₂e) and show no figures until they are entered. Left out, the activity emissions stay zero, and the screens say when zero is right. The entered figure is saved in the analysis as `activityEmissions`.

**What a visitor sees.**

- The fNRB source is named ("A6.4-AMT-009 Table 3 (national default)"), and the screens say its values come from MoFuSS.
- The tag key sits behind an info icon, in four plain lines. The "derived" tag is now "calculated". Visitor text says "methodology" throughout.
- A value entered now that monitoring or a baseline survey must prove later shows both marks, for example "ENTERED · MONITORING", with one plain line.
- The sliders read "Assumed: [value], a cautious estimate.", with one line on which way credits move. Their citations sit behind an info icon. The drinking-water slider says how a project claims more: a Water Consumption Field Test, up to the 5.50-liter cap (V2.0 SDWS 29, p.65; Annex 2, p.89).
- Planned production stays blank until given, and is asked in plain words.
- On the screening view (`exAnteOnly`), C_b is shown, not typed. V2.0 sets no default for it (SDWS 12, p.53), so the screen says 0% is the most generous value and that the baseline survey sets it later.
- The DAF row opens to show its working: the tool and its version, the inputs, Table 03 and the country's row. BAU_y is listed under "where".
- Starting values follow project details that arrive after the calculator opens. A value the person changed stays.
- Long symbols no longer run into their titles, notes wrap, and every equation number uses one small style.
- The Beta footer is just the word "Beta".

## Changes in 0.3.0

**Before you upgrade, a site that shows the transition must pass `creditedUnderV1: true` on every project credited under V1.0.** From 0.3.0, a project without it gets the V2.0-only view. Its transition, and the ask for its filed V1.0 fNRB, stop showing.

- New: the V2.0-only view for a new project, on the work surface and in the report (see "New projects and transitioning projects" above).
- `ReportView`: `legacyER` and `waterfall` may be left out. The report then covers V2.0 only.
- `CalculatorState` has `transition`: true when the screens show the transition.
- Fixed: Calvin's chat context no longer fails while a transitioning project's filed V1.0 fNRB is missing.
- Fixed: the figure tiles fit the width of their panel and no longer overlap at laptop width.
- Calvin needs `@waterbots/core` 0.1.1. Core's only change is its package file, which no longer has a `url` line.

No sum changed. The engine version and every test case stay as they are.

## Notes

Since the seed landed, this repo is Calvin's home. Changes are made here, by pull request. `scripts/check-seed.mjs` proves what arrived against the commit where the seed landed, so later changes are allowed.

- Version 0.6.0. Not published. Nothing in this repo goes to npm yet; the package is marked `private`.
- The build writes plain files for a bundler to pick up. Apart from `dist/engine.js` and `dist/screen.js`, they do not run on their own in Node.
- Apache License 2.0. See `LICENSE` and `NOTICE` in this folder.
